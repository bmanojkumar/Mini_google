package searchengine.spider;

import javax.swing.JApplet;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.TextField;
import java.awt.Choice;

public class gui extends JApplet {
	private JTable table;

	/**
	 * Create the applet.
	 */
	public gui() {
		getContentPane().setLayout(null);
		
		table = new JTable();
		table.setBounds(227, 99, 1, 1);
		getContentPane().add(table);
		
		TextField textField = new TextField();
		textField.setBounds(31, 54, 136, 22);
		getContentPane().add(textField);
		
		Choice choice = new Choice();
		choice.add("list");
		choice.setBounds(206, 54, 49, 20);
		getContentPane().add(choice);
		
	}
}

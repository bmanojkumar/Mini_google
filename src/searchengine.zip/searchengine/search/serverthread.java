package searchengine.search;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.*;

import searchengine.dictionary.ObjectIterator;

public class serverthread extends Thread
{
	Socket socket;
	serverthread(Socket socket)
	{
		this.socket = socket;
	}
	
	public void run()
	{
		try {
			String message = null;
			BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			PrintWriter writer = new PrintWriter(socket.getOutputStream(),true);
			message = reader.readLine();
			
				String args[] = message.split(" ");
				//System.out.println(args);
				SearchDriver driver = new SearchDriver();
				driver.main(args);
				ObjectIterator<?> i = driver.i;
				String j= "";
				try
				{
					while(i.hasNext())
					{
						String k= (String) i.next();
						System.out.println(k);
						//j = j+k+"\n";
						writer.println(k);
					}
					
//					
					/*writer.print(j);
					writer.print("\n");
					writer.print(-1);
					*/
					
					/*System.out.println("Incoming client message : " + message);
					writer.println("from server" + message);*/
				}
				catch(Exception e)
				{
					
				}
			
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}